import collections
import itertools
import operator

from nl_expr.expression_pattern_matching import add_match
from nl_expr.expression_walker import ExpressionWalker, expression_iterator
from nl_expr.expressions import Constant, FunctionApplication, Symbol
from nl_expr.logic import (
    Conjunction,
    Disjunction,
    ExistentialPredicate,
    Negation,
)
from nl_expr.logic.expression_processing import extract_logic_atoms
from nl_expr.logic.transformations import (
    CollapseConjunctions,
    FactorConjunctQuantifiers,
    LogicExpressionWalker,
    RemoveTrivialOperations,
    convert_to_pnf_with_dnf_matrix,
)
from ..relational_algebra import Projection, Selection, int2columnint_constant
from .probabilistic_ra_utils import ProbabilisticFactSet

EQ = Constant(operator.eq)
NE = Constant(operator.ne)
LT = Constant(operator.lt)
LE = Constant(operator.le)
GT = Constant(operator.gt)
GE = Constant(operator.ge)
# The comparisons of a variable with a constant that are shattered, with
# their complement and with the comparison of the arguments swapped.
COMPLEMENT = {NE: EQ, LT: GE, LE: GT, GT: LE, GE: LT}
SWAPPED = {NE: NE, LT: GT, LE: GE, GT: LT, GE: LE}
RTO = RemoveTrivialOperations()


def atom_to_constant_to_RA_conditions(atom: FunctionApplication) -> set:
    conditions = set()
    for i, arg in enumerate(atom.args):
        if isinstance(arg, Constant):
            conditions.add(EQ(int2columnint_constant(i), arg))

    return conditions


class NormalizeNotEquals(LogicExpressionWalker):
    @add_match(
        FunctionApplication(Constant, (Constant, Symbol)),
        lambda expression: expression.functor in SWAPPED
    )
    def flip_ne_arguments(self, expression):
        return expression.apply(
            SWAPPED[expression.functor],
            expression.args[::-1]
        )


def conditions_per_symbol(ucq_query):
    ucq_query_dnf = convert_to_pnf_with_dnf_matrix(ucq_query)
    ucq_query_dnf = NormalizeNotEquals().walk(ucq_query_dnf)

    conditions_per_symbol = collections.defaultdict(set)
    number_of_args = dict()
    for atom in extract_logic_atoms(ucq_query_dnf):
        if not isinstance(atom.functor, Symbol):
            continue
        condition = atom_to_constant_to_RA_conditions(atom)
        conditions_per_symbol[atom.functor] |= condition
        number_of_args[atom.functor] = len(atom.args)

    conjunctions = (
        expression for _, expression in expression_iterator(ucq_query_dnf)
        if isinstance(expression, Conjunction) and
        any(
            _formula_is_ne(formula)
            for formula in expression.formulas
        )
    )

    for conjunction in conjunctions:
        nes = (
            formula for formula in conjunction.formulas
            if _formula_is_ne(formula)
        )
        for ne in nes:
            ne_symbol = ne.args[0]
            ne_constant = ne.args[1]
            for atom in extract_logic_atoms(conjunction):
                if not isinstance(atom.functor, Symbol):
                    continue
                ne_conditions = {
                    ne.functor(int2columnint_constant(i), ne_constant)
                    for i, s in enumerate(atom.args)
                    if s == ne_symbol
                }
                if ne_conditions:
                    conditions_per_symbol[atom.functor] |= ne_conditions
                    number_of_args[atom.functor] = len(atom.args)

    return conditions_per_symbol, number_of_args


def _formula_is_ne(formula):
    """Whether `formula` is the comparison of a variable with a constant,
    such as `variable ≠ constant`; comparisons between variables are not
    shattered.
    """
    return (
        isinstance(formula, FunctionApplication) and
        formula.functor in COMPLEMENT and
        isinstance(formula.args[0], Symbol) and
        isinstance(formula.args[1], Constant)
    )


def sets_per_symbol(ucq_query):
    cps, number_of_args = conditions_per_symbol(ucq_query)

    symbol_sets = dict()

    for symbol, conditions in cps.items():
        if len(conditions) == 0:
            continue
        # A partition of the column's values for its constants, and one
        # for each other comparison: the tuples of each set of the
        # product of these partitions are disjoint from those of others.
        column_conditions = collections.defaultdict(set)
        for condition in conditions:
            if condition.functor in (EQ, NE):
                column_conditions[condition.args[0]].add(
                    (EQ(*condition.args),)
                )
            else:
                column_conditions[condition] = {
                    (condition,),
                    (COMPLEMENT[condition.functor](*condition.args),)
                }

        for column, conditions in column_conditions.items():
            if isinstance(column, FunctionApplication):
                continue
            column_conditions[column].add(
                tuple(NE(*c[0].args) for c in conditions)
            )

        set_formulas = list(
            Conjunction(tuple(
                sorted(
                    itertools.chain(*conditions),
                    key=lambda exp: (
                        exp.args[0].value, exp.args[1].value,
                        exp.functor.value.__name__
                    )
                )
            ))
            for conditions in
            itertools.product(*column_conditions.values())
        )
        conditions_columns = [
            set(
                condition_item.args[0].value
                for condition_item in condition.formulas
                if condition_item.functor == EQ
            )
            for condition in set_formulas
        ]
        conditions_projected_args = [
            tuple(
                int2columnint_constant(i)
                for i in range(number_of_args[symbol])
                # if i not in condition_columns
            )
            for condition_columns in conditions_columns
        ]

        symbol_sets[symbol] = set(
            Projection(Selection(symbol, RTO.walk(condition)), projected_args)
            for condition, projected_args
            in zip(set_formulas, conditions_projected_args)
        )

    return symbol_sets


class ShatterEqualities(ExpressionWalker):
    def __init__(self, symbol_sets, symbol_table):
        self.symbol_sets = symbol_sets
        self.symbol_table = symbol_table
        self.shatter_symbols = dict()

    @add_match(FunctionApplication(Symbol, ...))
    def shatter_symbol(self, expression):
        expression = self._shatter_atom(expression)
        return expression

    def _shatter_atom(self, expression, nes=None):
        if expression.functor not in self.symbol_sets:
            return expression

        sets = self.symbol_sets[expression.functor]
        sets_to_keep = self._identify_sets_to_keep(expression, sets, nes=nes)

        expression, e_vars = self._compute_expression_arguments(
            expression, sets_to_keep
        )

        if len(expression) == 1:
            expression = expression[0]
        else:
            expression = Disjunction(expression)

        for e_var in e_vars:
            expression = ExistentialPredicate(e_var, expression)
        return expression

    @add_match(
        Conjunction,
        lambda expression: (
            any(
                _formula_is_ne(formula) and
                isinstance(formula.args[1], Constant)
                for formula in expression.formulas
            ) and
            # The inequalities are moved into the atoms, the other
            # conjuncts.
            all(
                isinstance(formula, FunctionApplication)
                for formula in expression.formulas
            )
        )
    )
    def shatter_inequalities(self, expression):
        nes = set()
        formulas_to_keep = []
        for formula in expression.formulas:
            if _formula_is_ne(formula):
                nes.add(formula)
            else:
                formulas_to_keep.append(formula)

        resulting_formulas = tuple()
        shattered_variables = set()
        for formula in formulas_to_keep:
            if formula.functor not in self.symbol_sets:
                resulting_formulas += (formula,)
            else:
                resulting_formulas += (self._shatter_atom(formula, nes=nes),)
                shattered_variables |= set(formula.args)

        if not shattered_variables:
            return expression
        # A comparison is in the sets of the atoms with its variable.
        return Conjunction(resulting_formulas + tuple(
            ne for ne in nes if ne.args[0] not in shattered_variables
        ))

    @add_match(
        Conjunction,
        lambda expression: (
            any(_formula_is_ne(formula) for formula in expression.formulas)
            and any(
                isinstance(formula, ExistentialPredicate)
                for formula in expression.formulas
            ) and not any(
                isinstance(e, (Negation, Disjunction))
                for _, e in expression_iterator(expression)
            )
        )
    )
    def comparison_into_existentials(self, expression):
        """C ∧ ∃x ψ ≡ ∃x (C ∧ ψ), x renamed apart: the comparisons with
        a constant are then in the conjunction of the atoms of their
        variable."""
        return self.walk(CollapseConjunctions().walk(
            FactorConjunctQuantifiers().walk(expression)
        ))

    def _compute_expression_arguments(self, expression, sets_to_keep):
        args = []
        for i, arg in enumerate(expression.args):
            if isinstance(arg, Symbol):
                args.append((i, arg, False))
            elif isinstance(arg, Constant):
                args.append((i, Symbol.fresh(), True))
        formulas = tuple()
        e_vars = set()
        for set_ in sets_to_keep:
            if set_ not in self.shatter_symbols:
                sym = Symbol.fresh()
                self.shatter_symbols[set_] = sym
                self.symbol_table[sym] = set_
            formula_args = []
            for i, arg, is_e_var in args:
                if int2columnint_constant(i) in set_.columns():
                    formula_args.append(arg)
                    if is_e_var:
                        e_vars.add(arg)
            formulas += (self.shatter_symbols[set_](*formula_args),)
        return formulas, e_vars

    def _identify_sets_to_keep(self, expression, sets, nes=None):
        conditions = atom_to_constant_to_RA_conditions(expression)
        negative_conditions = set()
        for ne in nes or ():
            negative_conditions |= {
                COMPLEMENT[ne.functor](int2columnint_constant(i), ne.args[1])
                for i, arg in enumerate(expression.args) if arg == ne.args[0]
            }
        sets_to_keep = []
        for set_ in sets:
            set_conditions = self._selection_formulas(set_)
            if (
                conditions <= set_conditions and
                set_conditions.isdisjoint(negative_conditions)
            ):
                sets_to_keep.append(set_)
        return sets_to_keep

    def _selection_formulas(self, set_):
        formula = set_.relation.formula
        if isinstance(formula, Conjunction):
            set_conditions = set(formula.formulas)
        else:
            set_conditions = {formula}
        return set_conditions


class RelationalAlgebraSelectionConjunction(ExpressionWalker):
    @add_match(Selection(..., Conjunction))
    def selection_conjunction(self, expression):
        and_ = Constant(operator.and_)
        formulas = expression.formula.formulas
        new_formula = formulas[0]
        for f in formulas[1:]:
            new_formula = and_(new_formula, f)
        return Selection(
            expression.relation,
            new_formula
        )


def shatter_constants(query, symbol_table, shatter_all=False):
    query = NormalizeNotEquals().walk(query)
    symbol_sets = sets_per_symbol(query)
    if not shatter_all:
        for k in list(symbol_sets.keys()):
            if not isinstance(symbol_table[k], ProbabilisticFactSet):
                del symbol_sets[k]
    old_keys = set(symbol_table.keys())
    se = ShatterEqualities(symbol_sets, symbol_table)
    query = se.walk(RTO.walk(query))
    new_keys = set(symbol_table) - old_keys
    rasc = RelationalAlgebraSelectionConjunction()
    for k in new_keys:
        symbol_table[k] = rasc.walk(symbol_table[k])
    return query
