"""
The example questions of the engines, for in-context learning.

Each engine can have a bank of questions with their SQUALL and Datalog
queries, the ``assistant_examples`` of its configuration (kept in
``engines/<engine>/examples.yaml``), and inherits the banks of the
engines it extends. The examples
put in the prompt are those whose question is the most similar to the
user's (:func:`select_examples`), ranked by BM25 over their words: no
embedding model is needed. Engines without a bank fall back on the
example queries of their configuration.
"""

import math
import re
from collections import Counter
from typing import NamedTuple, Optional

from neurolang_apps.utils import engine_registry

_WORD = re.compile(r"[a-z0-9]+")
STOP_WORDS = frozenset(
    "a an and are as at be by do does each for from give have in is it "
    "list of on or show that the their them there these this to what "
    "which who whose with".split()
)


class Example(NamedTuple):
    """A question with its queries, by language (``squall``, ``datalog``)."""

    question: str
    queries: dict

    def query(self, language: str) -> Optional[str]:
        """Return the query of the example in *language*, if any."""
        return self.queries.get(language)


def words(text: str) -> list:
    """Return the words of *text* that tell what it is about."""
    return [
        w for w in _WORD.findall(text.lower())
        if w not in STOP_WORDS
    ]


def _configuration_examples(engine_name: str) -> list:
    """
    Return the example queries of the engine's configuration.

    They have no question: the model sees them as examples of the
    syntax on the engine.
    """
    from neurolang_apps.utils.tui.commands import engine_examples
    examples = []
    for language, queries in engine_examples(engine_name).items():
        examples.extend(Example("", {language: q}) for q in queries)
    return examples


def load_examples(engine_name: str) -> list:
    """
    Return the examples of *engine_name*, from its banks or its config.

    The banks of the engines it ``extends`` come first, then its own:
    the ``neurosynth`` and ``neurostore`` engines share the bank of
    ``coordinate_meta_analysis``.
    """
    engines = engine_registry._load_yaml_config()["engines"]
    if engine_name not in engines:
        return []
    bank = engine_registry.resolve_engine_config(engines, engine_name).get(
        "assistant_examples"
    )
    if bank:
        return [
            Example(entry["question"], {
                language: entry[language].strip()
                for language in ("squall", "datalog")
                if entry.get(language)
            })
            for entry in bank
        ]
    if engine_name in engine_registry.list_engine_names():
        try:
            return _configuration_examples(engine_name)
        except ImportError:
            return []
    return []


def bm25_scores(query: str, documents: list, k1=1.5, b=0.75) -> list:
    """Return the BM25 score of each of the *documents* for *query*."""
    tokenized = [words(document) for document in documents]
    if not tokenized:
        return []
    average = sum(map(len, tokenized)) / len(tokenized) or 1.0
    frequency = Counter(w for document in tokenized for w in set(document))
    n = len(tokenized)
    scores = []
    for document in tokenized:
        counts = Counter(document)
        score = 0.0
        for word in set(words(query)):
            if word not in counts:
                continue
            idf = math.log(1 + (n - frequency[word] + 0.5) /
                           (frequency[word] + 0.5))
            tf = counts[word]
            score += idf * tf * (k1 + 1) / (
                tf + k1 * (1 - b + b * len(document) / average)
            )
        scores.append(score)
    return scores


def select_examples(
    examples: list, question: str, language: str, k: int,
    exclude: str = "",
) -> list:
    """
    Return the *k* examples in *language* most similar to *question*.

    Ties keep the order of the bank, so that its first, simplest
    examples come first. The example whose question is *exclude* is
    left out (to evaluate the assistant on its own bank).
    """
    candidates = [
        example for example in examples
        if example.query(language) and example.question != exclude
    ]
    scores = bm25_scores(question, [e.question for e in candidates])
    ranked = sorted(
        range(len(candidates)), key=lambda i: (-scores[i], i)
    )
    return [candidates[i] for i in ranked[:k]]
