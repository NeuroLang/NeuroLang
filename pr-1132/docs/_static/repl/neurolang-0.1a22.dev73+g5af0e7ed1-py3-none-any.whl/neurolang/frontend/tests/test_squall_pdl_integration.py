"""Tests for NeurolangPDL.execute_squall_program."""
import numpy as np
import pandas as pd
import pytest

from nl_expr.exceptions import ForbiddenDisjunctionError
from nl_expr.expressions import Symbol as ir_Symbol

from ..probabilistic_frontend import NeurolangPDL
from nl_expr.exceptions import (
    SquallSemanticError,
    WrongArgumentsInPredicateError,
)


@pytest.fixture
def nl():
    """Fresh NeurolangPDL instance with basic extensional facts."""
    engine = NeurolangPDL()
    engine.add_tuple_set(
        [("alice",), ("bob",), ("carol",)], name="person"
    )
    engine.add_tuple_set(
        [("alice",), ("carol",)], name="plays"
    )
    return engine


@pytest.fixture
def nl_counts():
    """Fixture: NeurolangPDL instance with item / item_count / quantity facts."""
    engine = NeurolangPDL()
    engine.add_tuple_set(
        [("a",), ("b",), ("c",), ("d",)], name="item"
    )
    engine.add_tuple_set(
        [("a", 0), ("a", 1), ("b", 2), ("c", 3)], name="item_count"
    )
    engine.add_tuple_set(
        [(i,) for i in range(5)], name="quantity"
    )
    return engine


# ---------------------------------------------------------------------------
# Rules-only programs return None
# ---------------------------------------------------------------------------

def test_execute_squall_rules_only_returns_none(nl):
    """define-as programs with no obtain clause return None."""
    result = nl.execute_squall_program(
        "define as Active every person that plays."
    )
    assert result is None


def test_execute_squall_rules_fire_into_program(nl):
    """Rules walked in via execute_squall_program are visible in solve_all."""
    nl.execute_squall_program(
        "define as Active every person that plays."
    )
    solution = nl.solve_all()
    assert "active" in solution
    assert (
        set(solution["active"].as_pandas_dataframe().iloc[:, 0].tolist())
        == {"alice", "carol"}
    )


def test_show_rewritten_squall_prints_all_rules(capsys, nl):
    """--show-rewritten must print all reachable define-as rules, not just the final query."""
    nl.execute_squall_program(
        "define as Active every Person that plays. "
        "define as Fanatic every Active that plays. "
        "obtain every Fanatic.",
        show_rewritten=True,
        dry_run=True,
    )
    captured = capsys.readouterr()
    assert "active" in captured.out
    assert "fanatic" in captured.out


# ---------------------------------------------------------------------------
# Single obtain clause returns NamedRelationalAlgebraFrozenSet
# ---------------------------------------------------------------------------

def test_execute_squall_single_obtain_returns_relation(nl):
    """A single obtain clause returns a NamedRelationalAlgebraFrozenSet."""
    from nl_core.utils.relational_algebra_set.pandas import (
        NamedRelationalAlgebraFrozenSet,
    )
    result = nl.execute_squall_program("obtain every Person that plays.")
    assert isinstance(result, NamedRelationalAlgebraFrozenSet)


def test_execute_squall_single_obtain_correct_rows(nl):
    """Test: obtain every Person that plays returns alice and carol."""
    result = nl.execute_squall_program("obtain every Person that plays.")
    rows = set(result.as_pandas_dataframe().iloc[:, 0].tolist())
    assert rows == {"alice", "carol"}


# ---------------------------------------------------------------------------
# Multiple obtain clauses return dict keyed obtain_0, obtain_1, …
# ---------------------------------------------------------------------------

def test_execute_squall_multiple_obtains_returns_dict(nl):
    """Multiple obtain clauses produce a dict with obtain_0 / obtain_1 keys."""
    result = nl.execute_squall_program(
        "obtain every Person that plays. "
        "obtain every Person."
    )
    assert isinstance(result, dict)
    assert set(result.keys()) == {"obtain_0", "obtain_1"}


def test_execute_squall_multiple_obtains_correct_rows(nl):
    """Each entry in the multi-obtain dict holds the right result set."""
    result = nl.execute_squall_program(
        "obtain every Person that plays. "
        "obtain every Person."
    )
    plays_rows = set(result["obtain_0"].as_pandas_dataframe().iloc[:, 0].tolist())
    all_rows = set(result["obtain_1"].as_pandas_dataframe().iloc[:, 0].tolist())
    assert plays_rows == {"alice", "carol"}
    assert all_rows == {"alice", "bob", "carol"}


# ---------------------------------------------------------------------------
# Combined rules + obtain in one program
# ---------------------------------------------------------------------------

def test_execute_squall_rules_then_obtain(nl):
    """Rules defined before obtain are visible to the query."""
    result = nl.execute_squall_program(
        "define as Active every person that plays. "
        "obtain every Active."
    )
    rows = set(result.as_pandas_dataframe().iloc[:, 0].tolist())
    assert rows == {"alice", "carol"}


# ---------------------------------------------------------------------------
# Comparison filtering
# ---------------------------------------------------------------------------

def test_execute_squall_comparison_filter(nl_counts):
    """Filtering with 'greater equal than' produces correct rows."""
    nl_counts.execute_squall_program(
        "define as Large every Item "
        "that has an item_count greater equal than 2."
    )
    solution = nl_counts.solve_all()
    rows = set(solution["large"].as_pandas_dataframe().iloc[:, 0].tolist())
    assert rows == {"b", "c"}


# ---------------------------------------------------------------------------
# Aggregation
# ---------------------------------------------------------------------------

def test_execute_squall_aggregation(nl_counts):
    """Aggregation rule produces correct per-item max values."""
    nl_counts.execute_squall_program(
        "define as max_items for every Item ?i ;"
        " where every Max of the Quantity where ?i item_count per ?i."
    )
    solution = nl_counts.solve_all()
    df = solution["max_items"].as_pandas_dataframe()
    # Build set of (item, max_count) pairs from whatever columns are present
    rows = set(map(tuple, df.values.tolist()))
    assert rows == {("a", 1), ("b", 2), ("c", 3)}


@pytest.fixture
def nl_author():
    """Fixture: NeurolangPDL with paper/author facts stored as author(paper, person)."""
    engine = NeurolangPDL()
    engine.add_tuple_set(
        [("p1",), ("p2",), ("p3",)], name="paper"
    )
    # 'a Person ~author' requires a Person EDB so the existential
    # variable is drawn from a bounded domain, not left unconstrained.
    engine.add_tuple_set(
        [("alice",), ("bob",)], name="person"
    )
    engine.add_tuple_set(
        [("p1", "alice"), ("p2", "alice"), ("p3", "bob")], name="author"
    )
    return engine


def test_execute_squall_tilde_inversion_end_to_end(nl_author):
    """~author inverts the default SQUALL argument order (paper, person) to (person, paper)."""
    result = nl_author.execute_squall_program(
        "obtain every Paper that a Person ~author."
    )
    rows = set(result.as_pandas_dataframe().iloc[:, 0].tolist())
    assert rows == {"p1", "p2", "p3"}


def test_execute_squall_tilde_inversion_in_relative_vp():
    """``that ~mentions a Study`` reads ``mentions(study, term)`` backwards."""
    engine = NeurolangPDL()
    engine.add_tuple_set([(1,), (2,)], name="study")
    engine.add_tuple_set([("pain",), ("fear",), ("joy",)], name="term")
    engine.add_tuple_set([(1, "pain"), (2, "fear")], name="mentions")
    result = engine.execute_squall_program(
        "obtain every Term that ~mentions a Study."
    )
    rows = set(result.as_pandas_dataframe().iloc[:, 0].tolist())
    assert rows == {"pain", "fear"}


def test_execute_squall_marg_query_walks_without_error():
    """Smoke test: MARG syntax parses and IR is accepted by the solver walk."""
    from nl_core.datalog.horn_clauses import Fol2DatalogTranslationException

    engine = NeurolangPDL()
    engine.add_tuple_set([("v1",), ("v2",)], name="voxel")
    engine.add_tuple_set([("s1",), ("s2",)], name="study")

    try:
        engine.execute_squall_program(
            "define as Published with probability every Voxel "
            "conditioned to every Study activates."
        )
    except Fol2DatalogTranslationException:
        pass  # Expected: reached rewrite_conditional_query — plumbing is OK
    except ForbiddenDisjunctionError:
        pass  # Also acceptable: disjunctive queries reached probabilistic solver
    except Exception as exc:
        pytest.fail(
            f"execute_squall_program raised an unexpected exception for MARG rule: "
            f"{type(exc).__name__}: {exc}"
        )


def test_execute_squall_arbitrary_aggregation():
    """
    'every Custom_func of the relation' aggregates over all free vars.

    Registers a Python function as an aggregation over a 1-column
    relation, verifies the rule walks without error.
    """
    from nl_expr.expressions import Symbol, Constant
    from nl_core.datalog.horn_clauses import Fol2DatalogTranslationException

    engine = NeurolangPDL()
    engine.add_tuple_set(
        [("a",), ("b",), ("c",)], name="item"
    )

    # Register a simple aggregation function in the engine's symbol table
    def collect_all(*values):
        return sorted(values)

    engine.symbol_table[Symbol("collect_all")] = Constant(collect_all)

    try:
        engine.execute_squall_program(
            "define as Result every Collect_all of the Item."
        )
    except Fol2DatalogTranslationException:
        pass  # Acceptable: reached datalog translation — plumbing is OK
    except Exception as exc:
        pytest.fail(
            f"execute_squall_program raised unexpectedly for arbitrary agg: "
            f"{type(exc).__name__}: {exc}"
        )


def test_execute_squall_conditioned_rule_produces_implication_with_condition():
    """
    Conditioned SQUALL rule reaches rewrite_conditional_query inside the engine.

    This is an integration boundary test: the SQUALL parser correctly produces
    an Implication with a Condition antecedent, and the walker reaches
    TranslateProbabilisticQueryMixin.rewrite_conditional_query.  The toy
    sentence deliberately uses mismatched head/body variables so
    Fol2DatalogTranslationException is raised there — NOT a parse error.

    The absence of a parse-level exception (SyntaxError, KeyError from a
    missing transformer handler, etc.) confirms that the conditioned-rule
    transformer methods are wired up end-to-end.
    """
    from nl_expr.exceptions import UnboundVariablesError
    from nl_core.datalog.horn_clauses import Fol2DatalogTranslationException

    engine = NeurolangPDL()
    engine.add_tuple_set([("v1",), ("v2",)], name="voxel")
    engine.add_tuple_set([("s1",), ("s2",)], name="study")

    # The sentence reaches rewrite_conditional_query which raises
    # Fol2DatalogTranslationException because the toy head variables are not
    # present in the conditioned body.  Any *other* exception means the
    # conditioned-rule plumbing is broken.
    try:
        engine.execute_squall_program(
            "define as probably Published every Voxel conditioned to every Study activates."
        )
        # If no exception: also acceptable (engine accepted the rule)
    except Fol2DatalogTranslationException:
        pass  # Expected: reached rewrite_conditional_query — plumbing is OK
    except ForbiddenDisjunctionError:
        pass  # Also acceptable: disjunctive queries reached probabilistic solver
    except UnboundVariablesError:
        pass  # Also acceptable: the rewritten rule reached the program
    except Exception as exc:
        pytest.fail(
            f"execute_squall_program raised an unexpected exception type for "
            f"conditioned rule (parse/walk plumbing broken?): {type(exc).__name__}: {exc}"
        )


def test_execute_squall_body_function_call():
    """Function call in rel_b position produces a valid body atom."""
    from nl_expr.exceptions import (
        UnboundVariablesError,
        WrongArgumentsInPredicateError,
    )
    from nl_core.datalog.horn_clauses import Fol2DatalogTranslationException

    engine = NeurolangPDL()
    engine.add_tuple_set([("a",), ("b",)], name="item_val")

    def close_enough(x, y):
        return abs(x - y) < 0.5

    from nl_expr.expressions import Symbol, Constant
    engine.symbol_table[Symbol("close_enough")] = Constant(close_enough)

    try:
        engine.execute_squall_program(
            "define as Near every Item_val that close_enough(?x, ?y) holds."
        )
    except Fol2DatalogTranslationException:
        pass  # Acceptable: reached datalog translation — plumbing is OK
    except UnboundVariablesError:
        pass  # Acceptable: ?x and ?y are only bound by close_enough
    except WrongArgumentsInPredicateError:
        pass  # Acceptable: the item is a third argument of close_enough
    except Exception as exc:
        pytest.fail(
            f"Body function call raised unexpected exception: "
            f"{type(exc).__name__}: {exc}"
        )


def test_execute_squall_variable_probability_fact():
    """'activates with probability ?p' accepts a label as the probability argument."""
    from nl_core.datalog.horn_clauses import Fol2DatalogTranslationException
    from nl_expr.expression_pattern_matching import (
        NeuroLangPatternMatchingNoMatch,
    )

    engine = NeurolangPDL()
    engine.add_tuple_set([("s1",), ("s2",)], name="study")

    try:
        engine.execute_squall_program(
            "define as Probable every Study that activates with probability ?p."
        )
        # Rule was accepted
    except (Fol2DatalogTranslationException, NeuroLangPatternMatchingNoMatch):
        pass  # Acceptable: reached datalog translation — plumbing is OK
    except Exception as exc:
        pytest.fail(
            f"Variable-probability fact raised unexpected exception: "
            f"{type(exc).__name__}: {exc}"
        )


def test_execute_squall_inline_expr_comparison():
    """
    'such that EUCLIDEAN(a,b) is lower than 5' works without a relay variable.

    This path: rel_s -> s_np_vp -> vpbe_rel -> rel_comp already exists.
    The test confirms the function-call expression is correctly used as the
    left operand of the comparison (not a relay variable).
    """
    import operator
    from nl_expr.expressions import Constant, FunctionApplication, Symbol
    from nl_expr.logic import Conjunction

    engine = NeurolangPDL()

    def my_dist(a, b):
        return abs(a - b)

    engine.symbol_table[Symbol("MY_DIST")] = Constant(my_dist)
    _ = engine.add_tuple_set([(1,), (3,), (10,)], name="point")

    # Parse: "such that MY_DIST(?x, ?x) is lower than 5"
    # Expected body contains: lt(MY_DIST(x, x), 5)  (no relay variable)
    # Note: uppercase function names in `and` position after another clause
    # require `such that` as introducer (the grammar's rel_s path).
    result = engine.execute_squall_program(
        "define as Close every Point (?x) "
        "such that MY_DIST(?x, ?x) is lower than 5."
    )
    assert result is None  # rules-only, no obtain

    # Inspect the intensional rule that was added
    idb = engine.program_ir.intensional_database()
    close_symb = next(k for k in idb if k.name == "close")
    rule = idb[close_symb].formulas[0]

    # Body must contain a FunctionApplication of lt (operator.lt)
    body = rule.antecedent
    formulas = body.formulas if isinstance(body, Conjunction) else [body]
    lt_atoms = [
        f for f in formulas
        if isinstance(f, FunctionApplication)
        and isinstance(f.functor, Constant)
        and f.functor.value is operator.lt
    ]
    assert len(lt_atoms) == 1, f"Expected one lt atom, got: {formulas}"
    lt_atom = lt_atoms[0]
    # Left operand must be FunctionApplication(MY_DIST, ...) — functor is a
    # Constant wrapping my_dist (registered via symbol_table) or Symbol("MY_DIST").
    lhs = lt_atom.args[0]
    assert isinstance(lhs, FunctionApplication), (
        f"Expected FunctionApplication as lt left arg, got: {lhs}"
    )
    # The functor may be Symbol("MY_DIST") or Constant(my_dist) depending on
    # when type resolution runs; either way it must NOT be a plain Symbol
    # representing a relay variable like ?d.
    assert not (isinstance(lhs.functor, Symbol) and lhs.functor.name != "MY_DIST"), (
        f"Unexpected relay-variable functor: {lhs.functor}"
    )


def test_execute_squall_compact_per_list():
    """
    'per ?i, ?j, ?k and per ?s' produces same head args as four separate per dims.

    Compact form: per ?i1, ?j1, ?k1 and per ?s
    Verbose form: per ?i1 and per ?j1 and per ?k1 and per ?s
    Both must produce an Implication whose consequent has >=4 args.
    """
    from typing import Iterable

    engine = NeurolangPDL()

    def agg_collect(vals: Iterable) -> float:
        return float(sum(vals))

    engine.add_symbol(agg_collect, name="agg_collect")
    _ = engine.add_tuple_set(
        [(1, 10, 100, "s1"), (2, 20, 200, "s2")], name="data"
    )

    engine.execute_squall_program(
        "define as Result with a probability of "
        "the Agg_collect of the Data (?v; _; _; ?s) "
        "per ?i1, ?j1, ?k1 and per ?s "
        "that data(?i1, ?j1, ?k1) holds."
    )

    idb = engine.program_ir.intensional_database()
    # The query-based prob-fact translation produces fresh predicates.
    # At least one rule must have a consequent with >=4 args
    # (the fresh det rule has prob_var + i1, j1, k1, s = 5 args).
    all_rules = [idb[k].formulas[0] for k in idb]
    arg_counts = [len(r.consequent.args) for r in all_rules]
    assert any(c >= 4 for c in arg_counts), (
        f"Expected a rule consequent with >=4 args, got arg counts: {arg_counts}"
    )


@pytest.fixture
def nl_ternary():
    """Engine with ternary weighs/term_weight and voxel relations."""
    engine = NeurolangPDL()
    engine.add_tuple_set([(1,), (2,)], name="study")
    rows = [(1, "pain", 0.5), (2, "fear", 0.9), (1, "fear", 0.1)]
    engine.add_tuple_set(rows, name="term_weight")
    engine.add_tuple_set(rows, name="weighs")
    engine.add_tuple_set([("v1",), ("v2",)], name="voxel")
    engine.add_tuple_set([("v1", 1), ("v2", 2)], name="reported")
    engine.add_tuple_set([("v1",)], name="schaefer_voxels")
    return engine


def _column0_set(result):
    return set(result.as_pandas_dataframe().iloc[:, 0].tolist())


def test_execute_squall_tuple_is_a_noun_in_where_conjunction(nl_ternary):
    """``where (?s; ?t; ?w) is a T and ?t is 'pain'`` filters on ``T``."""
    result = nl_ternary.execute_squall_program(
        "obtain every Study ?s where (?s; ?t; ?w) is a Term_weight "
        "and ?t is 'pain'."
    )
    assert _column0_set(result) == {1}


def test_execute_squall_prepositional_ternary_verb(nl_ternary):
    """``that weighs 'fear' with ?w`` reads ``weighs(s, 'fear', w)``."""
    result = nl_ternary.execute_squall_program(
        "obtain every Study ?s that weighs 'fear' with ?w."
    )
    assert _column0_set(result) == {1, 2}


def test_execute_squall_too_many_verb_objects_is_an_arity_error(
    nl_ternary
):
    """A ternary use of a binary relation is reported as an arity error."""
    nl_ternary.add_tuple_set([(1, "pain")], name="mentions")
    with pytest.raises(WrongArgumentsInPredicateError):
        nl_ternary.execute_squall_program(
            "obtain every Study ?s that mentions 'pain' with ?w."
        )


def test_execute_squall_adjective_complement_and_noun(nl_ternary):
    """``that is reported by a Study and that is a S`` keeps both."""
    result = nl_ternary.execute_squall_program(
        "obtain every Voxel that is reported by a Study "
        "and that is a Schaefer_voxels."
    )
    assert _column0_set(result) == {"v1"}


def test_execute_squall_where_tuple_is_noun():
    """
    'where (?i; ?j; ?k) is a Noun' expands to Noun(i, j, k) in rule body.

    The clause is semantically equivalent to 'that noun(?i, ?j, ?k) holds'.
    We verify that the rule body contains a FunctionApplication of voxel with 3 args.
    """
    from nl_expr.expressions import FunctionApplication, Symbol
    from nl_expr.logic import Conjunction

    engine = NeurolangPDL()
    _ = engine.add_tuple_set(
        [(0, 0, 0), (1, 1, 1)], name="voxel"
    )
    _ = engine.add_tuple_set(
        [(0, 0, 0, 10), (1, 1, 1, 20)], name="focus"
    )

    engine.execute_squall_program(
        "define as Near every Focus (?i2; ?j2; ?k2; ?s) "
        "where (?i2; ?j2; ?k2) is a Voxel."
    )

    idb = engine.program_ir.intensional_database()
    near_symb = next(k for k in idb if k.name == "near")
    rule = idb[near_symb].formulas[0]

    body = rule.antecedent
    formulas = body.formulas if isinstance(body, Conjunction) else [body]
    voxel_calls = [
        f for f in formulas
        if isinstance(f, FunctionApplication)
        and isinstance(f.functor, Symbol)
        and f.functor.name == "voxel"
    ]
    assert len(voxel_calls) == 1, (
        f"Expected exactly one voxel(...) call in body, got: {formulas}"
    )
    assert len(voxel_calls[0].args) == 3, (
        f"Expected voxel(i,j,k) with 3 args, got: {voxel_calls[0]}"
    )


def test_extension_e_where_integration(tmp_path):
    """Full program using 'where' instead of 'such that' produces same solution."""
    import pandas as pd
    from ..probabilistic_frontend import NeurolangPDL

    nl = NeurolangPDL()
    df = pd.DataFrame({"x": [1, 2, 3]})
    nl.add_tuple_set(df, name="item")
    df2 = pd.DataFrame({"x": [1, 2]})
    nl.add_tuple_set(df2, name="selected")

    # with 'such that'
    nl.execute_squall_program(
        "define as Result every Item (?x) such that ?x is a Selected."
    )
    sol_such = nl.solve_all()["result"].as_pandas_dataframe()

    nl2 = NeurolangPDL()
    nl2.add_tuple_set(df, name="item")
    nl2.add_tuple_set(df2, name="selected")

    # with 'where'
    nl2.execute_squall_program(
        "define as Result every Item (?x) where ?x is a Selected."
    )
    sol_where = nl2.solve_all()["result"].as_pandas_dataframe()

    assert set(sol_such["x"]) == set(sol_where["x"])


def test_extension_f_given_integration(tmp_path):
    """
    'given every X' parses to identical IR as 'conditioned to every X'.

    Approach:
    1. Parse both sentence variants with the SQUALL parser and compare the
       resulting Implication structures (functor, Condition antecedent type,
       and Condition sub-expression functors must be equal).
    2. Walk both programs into fresh engines and confirm neither raises an
       unexpected exception — the same exception type (if any) is acceptable
       since MARG engine limitations affect both paths equally.
    """
    from neurolang.frontend.datalog.squall_syntax_lark import parser as squall_parser
    from nl_core.probabilistic.expressions import Condition
    from nl_expr.logic import Implication

    COND_SENTENCE = (
        "define as Probmap with probability every Activation (?i; ?j; ?k) "
        "conditioned to every Selected_study (_)."
    )
    GIVEN_SENTENCE = (
        "define as Probmap with probability every Activation (?i; ?j; ?k) "
        "given every Selected_study (_)."
    )

    # --- IR structural comparison -------------------------------------------
    ir_cond = squall_parser(COND_SENTENCE)
    ir_given = squall_parser(GIVEN_SENTENCE)

    # Both should return an Implication (rules-only, no obtain clause)
    assert isinstance(ir_cond, Implication), (
        f"'conditioned to' parser returned {type(ir_cond).__name__}, expected Implication"
    )
    assert isinstance(ir_given, Implication), (
        f"'given' parser returned {type(ir_given).__name__}, expected Implication"
    )

    # Head functor must be the same predicate name
    assert ir_cond.consequent.functor == ir_given.consequent.functor, (
        f"Head functors differ: {ir_cond.consequent.functor!r} vs "
        f"{ir_given.consequent.functor!r}"
    )

    # Both antecedents must be a Condition (not a plain Conjunction/Atom)
    assert isinstance(ir_cond.antecedent, Condition), (
        f"'conditioned to' antecedent is {type(ir_cond.antecedent).__name__}, expected Condition"
    )
    assert isinstance(ir_given.antecedent, Condition), (
        f"'given' antecedent is {type(ir_given.antecedent).__name__}, expected Condition"
    )

    # The Condition's conditioned/conditioning sub-expressions must have the
    # same type and — where applicable — the same top-level functor.
    cond_body = ir_cond.antecedent.conditioned
    given_body = ir_given.antecedent.conditioned
    assert type(cond_body) == type(given_body), (
        f"Condition.conditioned types differ: {type(cond_body).__name__!r} vs "
        f"{type(given_body).__name__!r}"
    )

    cond_cond = ir_cond.antecedent.conditioning
    given_cond = ir_given.antecedent.conditioning
    assert type(cond_cond) == type(given_cond), (
        f"Condition.conditioning types differ: {type(cond_cond).__name__!r} vs "
        f"{type(given_cond).__name__!r}"
    )

    # For FunctionApplication nodes we can also compare functor names.
    from nl_expr.expressions import FunctionApplication
    if isinstance(cond_body, FunctionApplication) and isinstance(given_body, FunctionApplication):
        assert cond_body.functor == given_body.functor, (
            f"Condition.conditioned functors differ: {cond_body.functor!r} vs "
            f"{given_body.functor!r}"
        )
    if isinstance(cond_cond, FunctionApplication) and isinstance(given_cond, FunctionApplication):
        assert cond_cond.functor == given_cond.functor, (
            f"Condition.conditioning functors differ: {cond_cond.functor!r} vs "
            f"{given_cond.functor!r}"
        )

    # --- Engine walk: both variants must raise the same exception type -------
    from neurolang.frontend import NeurolangPDL
    import pandas as pd

    def _build_engine():
        nl = NeurolangPDL()
        df_act = pd.DataFrame({"i": [1, 2, 3], "j": [0, 0, 0], "k": [0, 0, 0]})
        nl.add_tuple_set(df_act, name="activation")
        study_ids = pd.DataFrame({"s": ["s1", "s2"]})
        nl.add_uniform_probabilistic_choice_over_set(study_ids, name="selected_study")
        return nl

    exc_cond = None
    exc_given = None

    try:
        _build_engine().execute_squall_program(COND_SENTENCE)
    except Exception as e:
        exc_cond = e

    try:
        _build_engine().execute_squall_program(GIVEN_SENTENCE)
    except Exception as e:
        exc_given = e

    assert type(exc_cond) == type(exc_given), (
        f"'conditioned to' raised {type(exc_cond).__name__} but "
        f"'given' raised {type(exc_given).__name__} — walk plumbing differs"
    )


def test_extension_d_for_each_integration(tmp_path):
    """Rule using 'for each' groupby produces same IR structure as 'per'."""
    from typing import Iterable

    def _build(keyword):
        nl = NeurolangPDL()

        def agg_collect(vals: Iterable) -> float:
            return float(sum(vals))

        nl.add_symbol(agg_collect, name="agg_collect")
        nl.add_tuple_set(
            [(1, 10, "s1"), (2, 20, "s2")], name="data"
        )
        nl.add_tuple_set([(10, 1, "s1"), (20, 2, "s2")], name="indexed")
        nl.execute_squall_program(
            f"define as Result with a probability of "
            f"the Agg_collect of the Data (?v; _; ?s) "
            f"{keyword} ?i, ?s "
            f"that indexed(?i, ?s) holds."
        )
        idb = nl.program_ir.intensional_database()
        # find the rule(s) whose consequent functor name contains "result"
        rules = [
            rule
            for pred_rules in idb.values()
            for rule in pred_rules.formulas
            if "result" in rule.consequent.functor.name.lower()
        ]
        return rules

    rules_per = _build("per")
    rules_foreach = _build("for each")
    assert rules_per, "No result rules found for 'per'"
    assert rules_foreach, "No result rules found for 'for each'"
    # Both variants must produce the same number of consequent args
    args_per = {len(r.consequent.args) for r in rules_per}
    args_foreach = {len(r.consequent.args) for r in rules_foreach}
    assert args_per == args_foreach, (
        f"'per' consequent arg counts {args_per} != 'for each' {args_foreach}"
    )


def test_extension_g_obtain_as_integration(tmp_path):
    """'obtain … as Name' defines a relation and exposes it in solve_all() under the lowercased name."""
    from neurolang.frontend import NeurolangPDL
    import pandas as pd

    nl = NeurolangPDL()
    df = pd.DataFrame({"x": [1, 2, 3], "y": [4, 5, 6]})
    nl.add_tuple_set(df, name="pair")

    nl.execute_squall_program(
        "obtain every Pair (?x; ?y) as My_pairs."
    )
    sol = nl.solve_all()
    assert "my_pairs" in sol, f"Expected 'my_pairs' in solution, got: {list(sol.keys())}"
    result_df = sol["my_pairs"].as_pandas_dataframe()
    assert len(result_df) == 3
    assert set(result_df.columns) == {"x", "y"}


def test_execute_squall_compound_rule():
    """Compound quantifier rule with deterministic body solves end-to-end."""
    from neurolang.frontend import NeurolangPDL

    nl = NeurolangPDL()
    nl.add_tuple_set([("s1", "A"), ("s2", "A"), ("s3", "B")], name="activates")
    nl.add_tuple_set([("s1", "x"), ("s2", "y"), ("s3", "x")], name="mentions")
    nl.add_tuple_set([("A",), ("B",)], name="region")
    nl.add_tuple_set([("x",), ("y",)], name="term")

    result = nl.execute_squall_program(
        "define as Cooccurrence for every Region ?r and for every Term ?t "
        "where ?s activates ?r and mentions ?t. "
        "obtain every Cooccurrence (?r; ?t) as P_rt."
    )
    df = result.as_pandas_dataframe()
    assert len(df) == 3
    assert set(df.columns) == {"r", "t"}
    assert set(df.itertuples(index=False, name=None)) == {
        ("A", "x"),
        ("A", "y"),
        ("B", "x"),
    }


def test_execute_squall_compound_probabilistic_rule_smoke():
    """
    Compound quantifier MARG rule parses and reaches translate_implication.

    Smoke test — full probabilistic solving is blocked by a pre-existing
    limitation (fol_query_to_datalog_program does not support ProbabilisticQuery
    in the head, and flatten_query does not support existential bodies). We
    verify the rule parses correctly and that the failure mode is the expected
    Fol2DatalogTranslationException, consistent with existing MARG smoke tests.
    """
    from neurolang.frontend import NeurolangPDL
    from nl_core.datalog.horn_clauses import Fol2DatalogTranslationException

    nl = NeurolangPDL()
    nl.add_tuple_set([("s1", "A"), ("s2", "A"), ("s3", "B")], name="activates")
    nl.add_tuple_set([("s1", "x"), ("s2", "y"), ("s3", "x")], name="mentions")
    nl.add_tuple_set([("A",), ("B",)], name="region")
    nl.add_tuple_set([("x",), ("y",)], name="term")
    nl.add_uniform_probabilistic_choice_over_set(
        [("s1",), ("s2",), ("s3",)], name="selected_study"
    )

    try:
        nl.execute_squall_program(
            "define as Cooccurrence with inferred probability "
            "for every Region ?r and for every Term ?t "
            "where a Selected_study ?s activates ?r and mentions ?t."
        )
    except Fol2DatalogTranslationException:
        pass  # Expected: reached translate_implication — plumbing is OK
    except ForbiddenDisjunctionError:
        pass  # Also acceptable: reached probabilistic solver
    except Exception as exc:
        pytest.fail(
            f"Unexpected exception when walking compound probabilistic rule: "
            f"{type(exc).__name__}: {exc}"
        )


def test_execute_squall_cbma_spatial_prior_ir():
    """
    CBMA-style spatial prior rule with EUCLIDEAN and proximity_indicator.

    Verifies that a ``rule_op_prob_agg`` rule with ``EUCLIDEAN(…)`` distance
    filter, ``for each`` groupby, and a registered ``proximity_indicator``
    aggregation function can be parsed and walked into the engine.
    """
    from typing import Iterable

    engine = NeurolangPDL()

    def euclidean(i1, j1, k1, i2, j2, k2):
        return ((i1 - i2) ** 2 + (j1 - j2) ** 2 + (k1 - k2) ** 2) ** 0.5
    engine.add_symbol(euclidean, name="EUCLIDEAN")

    def proximity_indicator(values: Iterable) -> float:
        return 1.0
    engine.add_symbol(proximity_indicator, name="proximity_indicator")

    _ = engine.add_tuple_set(
        [(0, 0, 0), (1, 1, 1), (2, 2, 2)], name="voxel"
    )
    _ = engine.add_tuple_set(
        [(0, 0, 0, "s1"), (3, 3, 3, "s1")], name="peak"
    )

    engine.execute_squall_program(
        "define as Voxel_reported with a probability of "
        "the Proximity_indicator of the Peak (?x2; ?y2; ?z2; ?s) "
        "for each ?x, ?y, ?z and for each ?s "
        "where (?x; ?y; ?z) is a Voxel "
        "and where EUCLIDEAN(?x, ?y, ?z, ?x2, ?y2, ?z2) is lower than 4."
    )

    idb = engine.program_ir.intensional_database()
    assert len(idb) > 0, "Expected at least one IDB rule after walking"

    found = False
    for _, union in idb.items():
        for rule in union.formulas:
            if "voxel_reported" in rule.consequent.functor.name:
                found = True
                body_str = str(rule.antecedent)
                assert "x" in body_str, (
                    f"Body should reference head vars: {body_str}"
                )
    assert found, (
        "No voxel_reported rule found in IDB: "
        f"{[k.name for k in idb.keys()]}"
    )


def test_set_backend_directive_in_squall_program(nl):
    """#set_backend directive at the top of a SQUALL program is processed correctly."""
    result = nl.execute_squall_program(
        "#set_backend('pandas').\n"
        "define as Active every Person that plays.\n"
        "obtain every Active."
    )
    # Single obtain returns the relation directly
    rows = list(result)
    assert len(rows) > 0, "Expected at least one row"


def test_execute_squall_where_label_is_constant_inlines_eq(nl):
    """?x is 'value' inlines the constant into IDB args so magic-sets can
    propagate it, without changing the semantics of the query.

    Before this fix, ``?r is 'target'`` produced ``eq(r, 'target')`` in the
    body. Magic-sets skipped builtin predicates (Constant functor) and never
    propagated the constant.  After inlining, the query rule becomes
    ``p('value', …) :- body`` and magic-sets sees the bound argument.
    """
    result = nl.execute_squall_program(
        "obtain every Person (?p) where ?p is 'alice'."
    )
    rows = list(result)
    assert len(rows) == 1, f"Expected 1 row, got {len(rows)}"
    assert rows[0][0] == "alice", f"Expected 'alice', got {rows[0][0]}"


def test_execute_squall_where_label_is_constant_multiple_predicates(nl):
    """The inlining also works when the body already contains multiple atoms."""
    result = nl.execute_squall_program(
        "obtain every Person (?p) where ?p is 'alice' "
        "and ?p plays."
    )
    pdf = result.as_pandas_dataframe()
    assert len(pdf) == 1, f"Expected 1 row, got {len(pdf)}"
    assert pdf.iloc[0, 0] == "alice", (
        f"Expected 'alice', got {pdf.iloc[0, 0]}"
    )


def test_execute_squall_where_label_is_constant_absent_from_set_column():
    """
    A ``where ?l is 'value'`` filter matching no row over a relation whose
    columns come from destroying a set of tuples returns an empty result.

    The constant is pushed below the set destruction, so the relation
    exploded into ``(I, J, K)`` is empty.  Before the fix, exploding an
    empty relation into several columns raised ``KeyError ['I', 'J']``.
    """
    engine = NeurolangPDL()
    engine.add_tuple_set(
        [("a", frozenset({(0, 0, 0), (1, 1, 1)})),
         ("b", frozenset({(2, 2, 2)}))],
        name="atlas",
    )
    engine.execute_datalog_program(
        """
        voxels(I, J, K, l) :- atlas(l, r), contains(r, (I, J, K)).
        labels(l, i, j, k) :- voxels(i, j, k, l)
        """
    )
    found = engine.execute_squall_program(
        "obtain every Labels (?l; ?i; ?j; ?k) where ?l is 'a'."
    )
    assert set(found) == {("a", 0, 0, 0), ("a", 1, 1, 1)}
    missing = engine.execute_squall_program(
        "obtain every Labels (?l; ?i; ?j; ?k) where ?l is 'zzz'."
    )
    assert len(missing) == 0


# ---------------------------------------------------------------------------
# Probabilistic choice syntax
# ---------------------------------------------------------------------------

def test_execute_equiprobable_choice_basic():
    """define as X as an equiprobable choice over Y creates a uniform choice."""
    nl = NeurolangPDL()
    nl.add_tuple_set([("s1",), ("s2",), ("s3",)], name="study")
    nl.execute_squall_program(
        "define as Selected_study as an equiprobable choice over every Study."
    )
    sym = ir_Symbol("selected_study")
    assert sym in nl.program_ir.pchoice_pred_symbs, (
        "selected_study should be registered as a probabilistic choice"
    )
    assert sym in nl.program_ir.symbol_table, (
        "selected_study should be in the symbol table"
    )
    choice_set = nl.program_ir.symbol_table[sym]
    rows = list(choice_set.value.itervalues())
    assert len(rows) == 3, f"Expected 3 rows, got {len(rows)}"
    # Each row has (probability, study_id)
    assert abs(rows[0][0] - 1.0 / 3) < 1e-9, (
        f"Expected probability 1/3, got {rows[0][0]}"
    )


def test_execute_equiprobable_choice_rules_only():
    """define as equiprobable choice without obtain returns None."""
    nl = NeurolangPDL()
    nl.add_tuple_set([("s1",), ("s2",)], name="study")
    result = nl.execute_squall_program(
        "define as Selected_study as an equiprobable choice over every Study."
    )
    assert result is None
    sym = ir_Symbol("selected_study")
    assert sym in nl.program_ir.pchoice_pred_symbs


def test_execute_equiprobable_choice_single_element():
    """A single-element source produces a choice with probability 1."""
    nl = NeurolangPDL()
    nl.add_tuple_set([("only_one",)], name="singleton")
    nl.execute_squall_program(
        "define as Choice as an equiprobable choice over every Singleton."
    )
    sym = ir_Symbol("choice")
    choice_set = nl.program_ir.symbol_table[sym]
    rows = list(choice_set.value.itervalues())
    assert len(rows) == 1
    assert abs(rows[0][0] - 1.0) < 1e-9


def test_execute_equiprobable_choice_multi_column():
    """Multi-column source — each tuple is a choice alternative."""
    nl = NeurolangPDL()
    nl.add_tuple_set([("s1", 1), ("s2", 2)], name="study_info")
    nl.execute_squall_program(
        "define as Selected as an equiprobable choice over every Study_info."
    )
    sym = ir_Symbol("selected")
    choice_set = nl.program_ir.symbol_table[sym]
    rows = list(choice_set.value.itervalues())
    assert len(rows) == 2
    assert abs(rows[0][0] - 0.5) < 1e-9
    assert abs(rows[1][0] - 0.5) < 1e-9


def test_conditional_query_intermediate_predicates_are_deterministic():
    """Regression: re-walking a conditional query must not create fresh intermediates."""
    engine = NeurolangPDL()
    engine.add_tuple_set([("v1",), ("v2",)], name="voxel")
    engine.add_tuple_set([("s1",), ("s2",)], name="study")

    engine.execute_squall_program(
        "define as Published with probability every Voxel "
        "conditioned to every Study activates."
    )

    cond_functors = set()
    idb = engine.program_ir.intensional_database()
    for ruleset in idb.values():
        for rule in ruleset.formulas:
            name = str(rule.consequent.functor)
            if "^cond_num" in name or "^cond_den" in name:
                cond_functors.add(name)

    assert len(cond_functors) == 2, (
        f"Expected 2 distinct intermediate functors, got {len(cond_functors)}: {cond_functors}"
    )


# ---------------------------------------------------------------------------
# Issue #877: SQUALL aggregations return the aggregate column
# ---------------------------------------------------------------------------

def test_execute_squall_count_obtain_returns_count_column(nl_counts):
    """
    'obtain every Count of the Item.' yields a single count column.

    Regression: the aggregation head was dropped, returning (N, 0).
    """
    result = nl_counts.execute_squall_program(
        "obtain every Count of the Item."
    )
    df = result.as_pandas_dataframe()
    assert df.shape == (1, 1), f"got {df.shape}"
    assert df.iloc[0, 0] == 4


def test_execute_squall_issue877_count_of_defined_relation(nl):
    """Issue-877 phrasing "'every ES of the ES count of the ES'" is a count."""
    nl.execute_squall_program(
        "define as ES every Person that plays."
    )
    result = nl.execute_squall_program(
        "obtain every ES of the ES count of the ES."
    )
    df = result.as_pandas_dataframe()
    assert df.shape == (1, 1), f"got {df.shape}"
    assert df.iloc[0, 0] == 2


def test_execute_squall_count_over_nary_relation():
    """Aggregation over an N-ary relation yields the aggregate column."""
    engine = NeurolangPDL()
    engine.add_tuple_set(
        [(0, 0, 0), (1, 1, 1), (2, 2, 2)], name="voxel"
    )
    engine.add_tuple_set([("s1",), ("s2",)], name="study")
    result = engine.execute_squall_program(
        "obtain every Voxel in 3D of the Study count of the Study."
    )
    df = result.as_pandas_dataframe()
    assert df.shape == (1, 1), f"got {df.shape}"
    assert df.iloc[0, 0] == 2


@pytest.fixture
def nl_study_tfidf():
    """Engine with a 3-column term_in_study_tfidf(study, term, tfidf)."""
    engine = NeurolangPDL()
    engine.add_tuple_set([(1,), (2,)], name="study")
    engine.add_tuple_set(
        [(1, "pain", 0.5), (2, "fear", 0.9), (1, "fear", 0.1)],
        name="term_in_study_tfidf",
    )
    return engine


def test_execute_squall_max_of_multicolumn_relation_asks_for_column(
    nl_study_tfidf
):
    """Unlabelled Max over a 3-column relation must not use column 0."""
    with pytest.raises(SquallSemanticError, match=r"\(_; _; \?\w+\)"):
        nl_study_tfidf.execute_squall_program(
            "obtain the Max of the Term_in_study_tfidf."
        )


def test_execute_squall_max_of_multicolumn_rule_asks_for_column(nl_study_tfidf):
    """The same ambiguity in a rule definition is reported too."""
    with pytest.raises(SquallSemanticError, match="3 columns"):
        nl_study_tfidf.execute_squall_program(
            "define as Top_tfidf every Max of the Term_in_study_tfidf."
        )


def test_execute_squall_count_message_uses_squall_name(nl_study_tfidf):
    """The aggregation is named as written, 'Count', not 'len'."""
    with pytest.raises(SquallSemanticError, match="'Count' over") as info:
        nl_study_tfidf.execute_squall_program(
            "obtain every Count of the Term_in_study_tfidf."
        )
    assert "'len'" not in str(info.value)


def test_execute_squall_count_of_probabilistic_facts_is_not_multicolumn():
    """The probability column of a fact set is not an aggregated column."""
    engine = NeurolangPDL()
    engine.add_probabilistic_facts_from_tuples(
        [(0.5, "a"), (0.2, "b")], name="pf"
    )
    engine.execute_squall_program("define as Pf_count every Count of the Pf.")


def test_execute_squall_max_of_named_column(nl_study_tfidf):
    """``(_; _; ?w)`` selects the value column to aggregate."""
    result = nl_study_tfidf.execute_squall_program(
        "obtain the Max of the Term_in_study_tfidf (_; _; ?w)."
    )
    assert result.as_pandas_dataframe().values.tolist() == [[0.9]]


def test_execute_squall_max_of_named_column_per_group(nl_study_tfidf):
    """``(?s; _; ?w) per ?s`` aggregates ``?w`` for each study."""
    result = nl_study_tfidf.execute_squall_program(
        "obtain every Max of the Term_in_study_tfidf (?s; _; ?w) per ?s."
    )
    rows = set(map(tuple, result.as_pandas_dataframe().values.tolist()))
    assert rows == {(1, 0.5), (2, 0.9)}


def test_execute_squall_issue879_anaphora_and_conjunction():
    """Anaphora + conjunction query completes instead of raising.

    Regression from the #878 conjunction reordering: for "a Study that
    mentions 'emotion' and mentions 'reward'", the reordered body splits
    the two mentions atoms, and the magic-sets rewrite produces an init
    rule with a free variable and an empty antecedent, rejected by the
    negation mixin as "All variables on the consequent need to be on the
    antecedent".
    """
    rng = np.random.RandomState(0)
    n_studies, n_peaks = 40, 150
    voxels = np.array(
        [[i, j, k] for i in range(25, 35) for j in range(25, 35)
         for k in range(25, 35)],
        dtype=np.int64,
    )
    pick = rng.randint(0, len(voxels), n_peaks)
    peaks = pd.DataFrame(
        np.c_[voxels[pick], rng.randint(1, n_studies + 1, n_peaks)],
        columns=["i", "j", "k", "study_id"],
    )
    studies = pd.DataFrame(
        np.arange(1, n_studies + 1, dtype=np.int64),
        columns=["study_id"],
    )
    terms = []
    for s in range(1, n_studies + 1):
        for t in ["emotion", "reward", "memory"]:
            if rng.rand() < 0.6:
                terms.append((t, float(rng.rand() * 3 + 0.01), s))
    term_data = pd.DataFrame(terms, columns=["term", "tfidf", "study_id"])

    nl = NeurolangPDL()
    nl.add_tuple_set(peaks, name="peak_reported")
    nl.add_tuple_set(studies, name="study")
    nl.add_tuple_set(term_data, name="term_in_study_tfidf")
    nl.add_tuple_set(voxels, name="voxel")
    nl.execute_datalog_program(
        "mentions(s, t) :- term_in_study_tfidf(t, v, s), (v > 0.001)"
    )
    nl.execute_datalog_program(
        "reported(i, j, k, s) :- peak_reported(i, j, k, s)"
    )
    nl.execute_datalog_program(
        "reports(i, j, k, s) :- reported(i, j, k, s)"
    )

    result = nl.execute_squall_program(
        "obtain every Voxel in 3D that a Study that mentions 'emotion' "
        "and mentions 'reward' reports."
    )
    df = result.as_pandas_dataframe()
    assert df.shape == (24, 3), f"got {df.shape}"



def test_execute_squall_derived_predicate_with_two_constants():
    """'every Study that mentions 'pain' and that mentions 'fear'' over a
    derived ``mentions`` relation completes instead of raising.

    The second ``mentions`` call is adorned with the study bound by the
    first one; the magic-sets rewrite used to seed it with a free study
    variable and an empty antecedent, rejected by the negation mixin as
    "All variables on the consequent need to be on the antecedent".
    """
    engine = NeurolangPDL()
    engine.add_tuple_set(
        [("s1", "pain", 0.5), ("s1", "fear", 0.2), ("s2", "pain", 0.3)],
        name="tfidf",
    )
    engine.add_tuple_set([("s1",), ("s2",)], name="study")
    engine.execute_datalog_program(
        "mentions(s, t) :- tfidf(s, t, w), (w > 0.01)"
    )
    result = engine.execute_squall_program(
        "obtain every Study that mentions 'pain' and that mentions 'fear'."
    )
    df = result.as_pandas_dataframe()
    assert set(df.iloc[:, 0]) == {"s1"}

# ---------------------------------------------------------------------------
# Top / Bottom aggregations (percentile- and count-based thresholds)
# ---------------------------------------------------------------------------

@pytest.fixture
def nl_tails():
    """Fixture: studies with measured z-scores."""
    engine = NeurolangPDL()
    engine.add_tuple_set([("s1",), ("s2",), ("s3",)], name="study")
    engine.add_tuple_set(
        [("s1", 0), ("s1", 1), ("s2", 2), ("s3", 3)], name="measured"
    )
    engine.add_tuple_set([(i,) for i in range(5)], name="zscore")
    return engine


def test_execute_squall_top_percent_obtain(nl_tails):
    """'obtain the Top 5% of the Zscore.' yields the 95th percentile."""
    result = nl_tails.execute_squall_program(
        "obtain the Top 5% of the Zscore."
    )
    df = result.as_pandas_dataframe()
    assert df.shape == (1, 1), f"got {df.shape}"
    assert abs(df.iloc[0, 0] - 3.8) < 1e-9


def test_execute_squall_bottom_percent_obtain(nl_tails):
    """'obtain the Bottom 5% of the Zscore.' yields the 5th percentile."""
    result = nl_tails.execute_squall_program(
        "obtain the Bottom 5% of the Zscore."
    )
    df = result.as_pandas_dataframe()
    assert df.shape == (1, 1), f"got {df.shape}"
    assert abs(df.iloc[0, 0] - 0.2) < 1e-9


def test_execute_squall_top_count_obtain(nl_tails):
    """'obtain the Top 2 of the Zscore.' yields the second-largest value."""
    result = nl_tails.execute_squall_program(
        "obtain the Top 2 of the Zscore."
    )
    df = result.as_pandas_dataframe()
    assert df.shape == (1, 1), f"got {df.shape}"
    assert df.iloc[0, 0] == 3


def test_execute_squall_top_count_exceeds_total(nl_tails):
    """
    A count threshold larger than the group size clamps to the smallest value:

    the whole z-score column (5 values) is within the top 100.
    """
    result = nl_tails.execute_squall_program(
        "obtain the Top 100 of the Zscore."
    )
    df = result.as_pandas_dataframe()
    assert df.shape == (1, 1), f"got {df.shape}"
    assert df.iloc[0, 0] == 0


def test_execute_squall_bottom_count_obtain(nl_tails):
    """'obtain the Bottom 2 of the Zscore.' yields the second-smallest value."""
    result = nl_tails.execute_squall_program(
        "obtain the Bottom 2 of the Zscore."
    )
    df = result.as_pandas_dataframe()
    assert df.shape == (1, 1), f"got {df.shape}"
    assert df.iloc[0, 0] == 1


def test_execute_squall_top_percent_grouped(nl_tails):
    """
    '… every Top 10% of the Zscore that the Study measured.' per study:

    s1 measured {0, 1} → 90th percentile 0.9; s2 and s3 single values.
    """
    result = nl_tails.execute_squall_program(
        "define as study_top10 for every Study ; "
        "where every Top 10% of the Zscore that the Study measured. "
        "obtain every study_top10."
    )
    df = result.as_pandas_dataframe()
    assert df.shape == (3, 2), f"got {df.shape}"
    rows = sorted(df.itertuples(index=False, name=None), key=lambda r: str(r[0]))
    assert abs(rows[0][1] - 0.9) < 1e-9
    assert rows[1][1] == 2
    assert rows[2][1] == 3


# ---------------------------------------------------------------------------
# Issue #877: canonical probabilistic overlay program completes and its
# conditional-query join does not materialise structural cross products
# ---------------------------------------------------------------------------

def _build_issue877_engine():
    """Small engine-shaped corpus for the canonical overlay program."""
    engine = NeurolangPDL()
    engine.add_tuple_set(
        [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1)], name="voxel"
    )
    engine.add_tuple_set([("s1",), ("s2",), ("s3",)], name="study")
    engine.add_tuple_set([("s1",), ("s2",)], name="selectedstudy")
    engine.add_tuple_set(
        [
            ("s1", 0, 0, 0),
            ("s1", 0, 0, 1),
            ("s1", 1, 1, 1),
            ("s2", 0, 0, 1),
        ],
        name="reported",
    )
    engine.add_tuple_set(
        [("s1", "emotion"), ("s2", "emotion"), ("s3", "language")],
        name="mentions",
    )

    def agg_create_region_overlay(i, j, k, p):
        return ("overlay", len(i))

    engine.add_symbol(
        agg_create_region_overlay, name="create_region_overlay"
    )
    return engine


def test_execute_squall_issue877_overlay_program_completes():
    """
    The canonical conditional-probability overlay program terminates and
    yields a single overlay.
    """
    engine = _build_issue877_engine()
    engine.execute_squall_program(
        "define as TermVoxels with inferred probability every Voxel in 3D "
        "that a SelectedStudy reported conditioned to the SelectedStudy "
        "mentions 'emotion'."
        " define as EmotionOverlay every create_region_overlay of the "
        "TermVoxels in 4D."
    )
    result = engine.execute_squall_program(
        "obtain every EmotionOverlay."
    )
    df = result.as_pandas_dataframe()
    assert df.shape == (1, 1), f"expected a single overlay, got {df.shape}"


def test_execute_squall_issue877_cond_num_join_no_cross_product():
    """
    The MARG numerator rule must join atoms sharing variables first.

    Regression: the numerator joined `voxel(x, y, z)` with
    `selectedstudy(s)` first, materialising a voxel x study cross product
    that makes the probabilistic solve hang at scale.
    """
    from nl_core.datalog.expression_processing import (
        extract_logic_free_variables,
    )

    engine = _build_issue877_engine()
    engine.execute_squall_program(
        "define as TermVoxels with inferred probability every Voxel in 3D "
        "that a SelectedStudy reported conditioned to the SelectedStudy "
        "mentions 'emotion'."
    )

    num_rules = []
    idb = engine.program_ir.intensional_database()
    for ruleset in idb.values():
        for rule in ruleset.formulas:
            if "^cond_num" in str(rule.consequent.functor):
                num_rules.append(rule)
    assert len(num_rules) == 1, f"expected one cond_num rule, got {num_rules}"

    formulas = tuple(num_rules[0].antecedent.formulas)
    assert all(
        isinstance(f, ir_Symbol) or hasattr(f, "args")
        for f in formulas
    ), "expected flat conjunction of atoms"
    atom_vars = [extract_logic_free_variables(f) for f in formulas]
    for i in range(len(formulas) - 1):
        if not atom_vars[i] & atom_vars[i + 1]:
            remaining = set().union(*atom_vars[i + 1:])
            assert not atom_vars[i] & remaining, (
                f"atoms {i} and {i + 1} share no variable while later "
                f"atoms do: {formulas}"
            )


@pytest.mark.slow
def test_execute_squall_issue877_overlay_program_scaled():
    """
    The canonical overlay program at a scale that used to blow up into a
    voxel x study cross product; completes in seconds with the fix.
    """
    import numpy as np

    rng = np.random.default_rng(42)
    grid = np.array(
        np.meshgrid(np.arange(24), np.arange(24), np.arange(24), indexing="ij")
    ).reshape(3, -1).T
    voxels = grid[rng.choice(grid.shape[0], size=13824, replace=False), :]

    engine = NeurolangPDL()
    engine.add_tuple_set(
        [tuple(map(int, v)) for v in voxels], name="voxel"
    )
    engine.add_tuple_set(
        [("s%d" % i,) for i in range(723)], name="study"
    )
    engine.add_tuple_set(
        [("s%d" % i,) for i in range(723)], name="selectedstudy"
    )
    engine.add_tuple_set(
        [("s%d" % i, "emotion") for i in range(723)], name="mentions"
    )
    engine.add_tuple_set(
        [
            ("s%d" % (i % 723), int(voxels[i % 13824, 0]),
             int(voxels[i % 13824, 1]), int(voxels[i % 13824, 2]))
            for i in range(5000)
        ],
        name="reported",
    )

    def agg_create_region_overlay(i, j, k, p):
        return ("overlay", len(i))

    engine.add_symbol(
        agg_create_region_overlay, name="create_region_overlay"
    )
    engine.execute_squall_program(
        "define as TermVoxels with inferred probability every Voxel in 3D "
        "that a SelectedStudy reported conditioned to the SelectedStudy "
        "mentions 'emotion'."
        " define as EmotionOverlay every create_region_overlay of the "
        "TermVoxels in 4D."
    )
    result = engine.execute_squall_program(
        "obtain every EmotionOverlay."
    )
    assert result.as_pandas_dataframe().shape == (1, 1)


def test_where_anaphora_marginal_matches_relative_clause_form():
    """
    Check 'where … the Term' and 'that' give the same conditional marginal.

    Before the anaphora fix the 'where' form recursed forever when the
    rule had a 'conditioned to' clause.
    """
    def marginal(sentence):
        nl = NeurolangPDL()
        nl.add_tuple_set(
            [("pain",), ("memory",), ("vision",)], name="term"
        )
        nl.add_uniform_probabilistic_choice_over_set(
            [(1,), (2,), (3,), (4,)], name="selected_study"
        )
        nl.add_tuple_set(
            [
                (1, "pain"), (1, "working memory"),
                (2, "working memory"), (2, "memory"),
                (3, "vision"),
                (4, "working memory"), (4, "pain"),
            ],
            name="mentions",
        )
        nl.execute_squall_program(sentence)
        df = nl.solve_all()["tm"].as_pandas_dataframe()
        return {row[0]: round(row[1], 6) for row in df.values.tolist()}

    condition = "conditioned to the Selected_study that mentions 'working memory'."
    where_form = marginal(
        "define as tm with inferred probability every Term where a "
        f"Selected_study mentions the Term {condition}"
    )
    that_form = marginal(
        "define as tm with inferred probability every Term that a "
        f"Selected_study mentions {condition}"
    )
    assert where_form == that_form == {"pain": round(2 / 3, 6), "memory": round(1 / 3, 6)}
